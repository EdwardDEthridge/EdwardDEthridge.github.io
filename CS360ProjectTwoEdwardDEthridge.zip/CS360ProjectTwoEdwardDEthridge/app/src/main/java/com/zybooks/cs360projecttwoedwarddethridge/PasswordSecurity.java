package com.zybooks.cs360projecttwoedwarddethridge;

import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

// FIXME: implement login credentials check
// this class allows us to store passwords securely instead of just plain text
public class PasswordSecurity {

    public static String hashPassword(String password) {
        // start by attempting to use our algorithm to create a hash
        try {
            // array of salts to allow multiple users to have the same password
            byte[] salt = new byte[16];
            // randomizer
            SecureRandom random = new SecureRandom();
            // chooses a random salt from our array
            random.nextBytes(salt);

            // create values for generating the password hash
            KeySpec spec = new PBEKeySpec(
                    // turns the plain text password into a character array
                    password.toCharArray(),
                    // this is our randomly selected salt value
                    salt,
                    // this is the number of times the password is hashed
                    6000,
                    // this is the length of our security algorithm
                    256
            );

            // this is the algorithm we are using to securely generate our password hash
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            // this does the actual hashing of the password
            byte[] hash = factory.generateSecret(spec).getEncoded();

            // stores our salt and our hash value
            return bytesToHex(salt) + ":" + bytesToHex(hash);

            // if algorithm doesn't exist throw an exception
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException(e);
        }
    }

    // this checks password validity by comparing hash values
    public static boolean passwordChecker(String password, String storedHash) {
        try {
            //Separates the stored string into parts so we get the salt and the hash
            String[] saltAndHash = storedHash.split(":");

            // storing each part of the string in different variables to use for comparison
            String saltString = saltAndHash[0];
            String passwordHash = saltAndHash[1];

            // convert the string salt into bytes to use in our algorithm
            byte[] saltBytes = hexToBytes(saltString);

            // create values for generating the password hash
            KeySpec spec = new PBEKeySpec(
                    // turns the plain text password into a character array
                    password.toCharArray(),
                    // this is our randomly selected salt value
                    saltBytes,
                    // this is the number of times the password is hashed
                    6000,
                    // this is the length of our security algorithm
                    256
            );

            // this is the algorithm we are using to securely generate our password hash
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            // this does the actual hashing of the password
            byte[] hash = factory.generateSecret(spec).getEncoded();

            // returns a comparison of our hashed password and the stored password hash
            return bytesToHex(hash).equals(passwordHash);

            // if algorithm doesn't exist throw an exception
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException(e);
        }
    }

    // this allows us to change the byte array back into a string for comparison
    private static String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();

        // for every byte, convert to a string
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }

        // return the hash as a string
        return result.toString();
    }
    // changes a string into byte array for comparison
    public static byte[] hexToBytes(String hex) {
        int length = hex.length();
        byte[] bytes = new byte[length / 2];

        // for every pair of characters
        for (int i = 0; i < length; i += 2) {
            //c change the character pair into a byte using base 16
            bytes[i / 2] = (byte) Integer.parseInt(
                    hex.substring(i, i + 2),
                    16
            );
        }

        return bytes;
    }
}