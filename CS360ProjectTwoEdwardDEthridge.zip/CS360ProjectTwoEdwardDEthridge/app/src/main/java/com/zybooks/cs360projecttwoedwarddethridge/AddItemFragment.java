package com.zybooks.cs360projecttwoedwarddethridge;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.room.Room;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class AddItemFragment extends Fragment {

    private long refillDate = 0;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.fragment_add_item, container, false);

        // creates text fields to be edited
        EditText itemName = rootView.findViewById(R.id.itemNameField);
        EditText itemQuantity = rootView.findViewById(R.id.itemQuantityField);
        EditText daysOfSupply = rootView.findViewById(R.id.daysOfSupplyField);
        TextView dateText = rootView.findViewById(R.id.dateField);

        // instantiates our buttons for use
        Button cancelButton = rootView.findViewById(R.id.cancelButton);
        Button confirmButton = rootView.findViewById(R.id.confirmButton);
        Button dateButton = rootView.findViewById(R.id.dateButton);

        //connect to db instance
        ProjectDatabase db = Room.databaseBuilder(
                requireContext(),
                ProjectDatabase.class,
                "user-database"
        ).fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        // allows use of our DAO class for interaction with the database
        ItemDAO itemDAO = db.itemDAO();

        // click listener when cancel is clicked returns to the grid screen
        cancelButton.setOnClickListener(v -> {
            NavHostFragment.findNavController(AddItemFragment.this)
                    .navigate(R.id.action_add_to_grid);
        });


        // click listener for the date selector button
        dateButton.setOnClickListener(v -> {
            DateManager.showDatePicker(
                    requireContext(),
                    selectedDate -> {refillDate = selectedDate;

                        dateText.setText(DateManager.formatDate(selectedDate));
                    }
            );

        });

        // checks to see if the confirm button is clicked
        confirmButton.setOnClickListener(v -> {

            String newItemName = itemName.getText().toString();
            String newItemQuantity = itemQuantity.getText().toString();

            //if either field is empty, reject and display message
            if(newItemName.isEmpty() && newItemQuantity.isEmpty()) {
                Toast.makeText(requireContext(),
                        "please enter an item name and a quantity",
                        Toast.LENGTH_SHORT).show();
            }
            //if item already exists do not create new item
            else if (itemDAO.itemExists(newItemName)){
                Toast.makeText(requireContext(),
                        "Item already exists",
                        Toast.LENGTH_SHORT).show();
            }
            // if refill date is not selected inform user and do not proceed
            else if(refillDate == 0){
                Toast.makeText(requireContext(),
                        "Please enter a refill date",
                        Toast.LENGTH_SHORT).show();
            }else {
                // if quantity is not a number, reject it and display message
                try {
                    int numberChecker = Integer.parseInt(newItemQuantity);
                } catch (NumberFormatException e) {
                    Toast.makeText(requireContext(), "Quantity must be a number",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                // check that days of supply is a number otherwise reject and inform user
                try {
                    int dosChecker = Integer.parseInt(daysOfSupply.getText().toString());
                } catch (NumberFormatException e){
                    Toast.makeText(requireContext(), "Days of supply must be a number",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                // gets our users username for use in adding an item
                SessionManager session = new SessionManager(requireContext());
                String username = session.getUsername();

                // calculates the next refill date based on day medicine is picked up and how many days medicine should last
                long nextRefillDate = DateManager.addDays(refillDate,Integer.parseInt(daysOfSupply.getText().toString()));

                //add new item to table
                itemDAO.addItem(new ItemTable(newItemName, Integer.parseInt(newItemQuantity), username, nextRefillDate));
                //display message that item was added successfully
                Toast.makeText(requireContext(),
                        "item added successfully",
                        Toast.LENGTH_SHORT).show();
                //navigate back to the grid screen
                NavHostFragment.findNavController(AddItemFragment.this)
                        .navigate(R.id.action_add_to_grid);
            }
        });

        return rootView;
    }
}