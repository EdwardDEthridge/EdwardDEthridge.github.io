package com.zybooks.cs360projecttwoedwarddethridge;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.room.Room;

import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class UpdateItemFragment extends Fragment {
    private long refillDate = 0;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_update_item, container, false);


        // enables our text fields to be interacted with
        TextView itemName = rootView.findViewById(R.id.itemNameField);
        EditText itemQuantity = rootView.findViewById(R.id.itemQuantityField);
        EditText daysOfSupply = rootView.findViewById(R.id.daysOfSupplyField);
        TextView dateText = rootView.findViewById(R.id.dateField);

        // instantiates our buttons for use
        Button cancelButton = rootView.findViewById(R.id.cancelButton);
        Button confirmButton = rootView.findViewById(R.id.confirmButton);
        Button dateButton = rootView.findViewById(R.id.dateButton);

        //connect to db instance
        ProjectDatabase db = Room.databaseBuilder(
                requireContext(),
                ProjectDatabase.class,
                "user-database"
        ).fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        // allows use of our DAO class for interaction with the database
        ItemDAO itemDAO = db.itemDAO();
        // gets the item selected
        Bundle bundle = getArguments();
        long itemId = bundle.getLong("itemId");

        // sets our textview to the existing item
        ItemTable existingItem = itemDAO.getItemById(itemId);
        itemName.setText(existingItem.name);
        itemQuantity.setText(String.valueOf(existingItem.quantity));

        // click listener when cancel is clicked returns to the grid screen
        cancelButton.setOnClickListener(v -> {
            NavHostFragment.findNavController(UpdateItemFragment.this)
                    .navigate(R.id.action_update_to_grid);
        });

        // click listener for the date selector button
        dateButton.setOnClickListener(v -> {
            DateManager.showDatePicker(
                    requireContext(),
                    selectedDate -> {refillDate = selectedDate;

                        dateText.setText(DateManager.formatDate(selectedDate));
                    }
            );

        });

        // click listener for the Confirm button
        confirmButton.setOnClickListener(v -> {

            // capture user input
            String updateItemQuantity = itemQuantity.getText().toString();
            String updateDOS = daysOfSupply.getText().toString();

            // if any fields are empty
            if (updateItemQuantity.isEmpty() || updateDOS.isEmpty() || refillDate == 0) {
                Toast.makeText(requireContext(),
                        "Please fill out all fields",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            int qty;

            //check if input for quantity is a number
            try {
                qty = Integer.parseInt(updateItemQuantity);
            } catch (NumberFormatException e) {
                Toast.makeText(requireContext(),
                        "Quantity must be a number",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            // check that days of supply is a number otherwise reject and inform user
            try {
                int dosChecker = Integer.parseInt(updateDOS);
            } catch (NumberFormatException e){
                Toast.makeText(requireContext(), "Days of supply must be a number",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            // calculates the next refill date based on day medicine is picked up and how many days medicine should last
            long nextRefillDate = DateManager.addDays(refillDate,Integer.parseInt(daysOfSupply.getText().toString()));

            // store values for updating
            existingItem.quantity = qty;
            existingItem.date = nextRefillDate;

            // invokes our session manager to get the username
            SessionManager session = new SessionManager(requireContext());
            existingItem.username = session.getUsername();

            //update item in table
            itemDAO.updateItem(existingItem);

            //inform user item was updated successfully
            Toast.makeText(requireContext(),
                    "Item updated successfully",
                    Toast.LENGTH_SHORT).show();
            try {
                //if quantity updated to 0, send sms message to emulator warning of out of stock
                if (qty == 0) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("5554", null, "Refill due!",
                            null, null);
                }
            } catch (Exception e) {
                Toast.makeText(requireContext(),
                        "SMS permissions denied go to notifications to accept",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            //navigate back to the grid
            NavHostFragment.findNavController(UpdateItemFragment.this)
                    .navigate(R.id.action_update_to_grid);
        });
        return rootView;
    }
}