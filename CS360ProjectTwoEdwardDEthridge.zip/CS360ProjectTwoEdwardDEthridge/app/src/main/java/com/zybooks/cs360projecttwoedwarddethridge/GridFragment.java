package com.zybooks.cs360projecttwoedwarddethridge;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.ArrayList;
import java.util.List;

public class GridFragment extends Fragment {
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.fragment_grid, container, false);

        // click listener when logout is clicked returns to the login screen
        Button logoutButton = rootView.findViewById(R.id.logout_button);
        logoutButton.setOnClickListener(v -> {
            // clears the session manager of the username
            SessionManager session = new SessionManager(requireContext());
            session.logout();
            // navigate back to log in screen
            NavHostFragment.findNavController(GridFragment.this)
                    .navigate(R.id.action_grid_to_login);
        });

        // click listener when notifications is clicked navigates to sms notification prompt
        Button notificationButton = rootView.findViewById(R.id.notificationButton);
        notificationButton.setOnClickListener(v -> {
            NavHostFragment.findNavController(GridFragment.this)
                    .navigate(R.id.action_grid_to_sms);
        });

        // click listener when add item is clicked navigates to add item screen
        Button addItemButton = rootView.findViewById(R.id.add_item_button);
        addItemButton.setOnClickListener(v -> {
            NavHostFragment.findNavController(GridFragment.this)
                    .navigate(R.id.action_grid_to_add);
        });

        //click listener to open the add item dialog
        return rootView;
    }
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        //connect to our database
        ProjectDatabase db = Room.databaseBuilder(
                requireContext(),
                ProjectDatabase.class,
                "user-database"
        ).fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        // enable our dao so we can interact with our database
        ItemDAO itemDAO = db.itemDAO();

        // connect to recycler view for use in our grid
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);

        //adapter for our recycler view
        ItemAdapter adapter = new ItemAdapter(itemDAO, new ArrayList<>());
        recyclerView.setAdapter(adapter);

        // creates a grid with each item stacked vertically
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 1));

        SessionManager session = new SessionManager(requireContext());
        String username = session.getUsername();

        // populate data in grid with items created by specific user
        List<ItemTable> items = itemDAO.getAllItems(username);
        adapter.setItems(items);
    }
}
