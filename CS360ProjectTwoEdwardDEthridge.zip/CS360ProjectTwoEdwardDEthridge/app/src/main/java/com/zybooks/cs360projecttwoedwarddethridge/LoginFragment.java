package com.zybooks.cs360projecttwoedwarddethridge;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.room.Room;

public class LoginFragment extends Fragment {
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.fragment_login, container, false);

        // instantiates our button functionality
        Button submitButton = rootView.findViewById(R.id.submitButton);
        Button createNewUser = rootView.findViewById(R.id.createNewUser);

        // makes the text fields editable
        EditText usernameField = rootView.findViewById(R.id.usernameField);
        EditText passwordField = rootView.findViewById(R.id.passwordField);

        // creates a database instance
        ProjectDatabase db = Room.databaseBuilder(
                requireContext(),
                        ProjectDatabase.class,
                        "user-database"
                ).fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        // allows use of our DAO class for interaction with the database
        UserDAO userDAO = db.userDAO();

        // click listener when submit button clicked move to database grid
        submitButton.setOnClickListener(v -> {
            String username = usernameField.getText().toString();
            String password = passwordField.getText().toString();

            UserTable user = userDAO.getUser(username);

            //if username exists in database
            if(user != null) {
                String storedPassword = user.password;

                boolean passIsValid = PasswordSecurity.passwordChecker(password, storedPassword);
                if(passIsValid) {

                    // invokes our session manager to store the username for later use
                    SessionManager session = new SessionManager(requireContext());
                    session.login(username);

                    // navigate to the grid screen
                    NavHostFragment.findNavController(LoginFragment.this)
                            .navigate(R.id.action_login_to_grid);

                    //display short message to user that login is successful
                    Toast.makeText(requireContext(),
                            "login successful",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(requireContext(),
                            "invalid password",
                            Toast.LENGTH_SHORT).show();
                }
            }
            //otherwise, reject login do not navigate to grid screen and display message
            else {
                Toast.makeText(requireContext(),
                        "username and password invalid",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // adds a click listener to the create new user button
        createNewUser.setOnClickListener(v -> {
            String username = usernameField.getText().toString();
            String password = passwordField.getText().toString();

            //if username or password are empty inform user that they must enter username and password
            if(username.isEmpty() || password.isEmpty()) {
                Toast.makeText(requireContext(),
                        "username and password can't be empty",
                        Toast.LENGTH_SHORT).show();
            } else if (userDAO.userExists(username)){
                //if created user matches existing user, do not create new user
                    Toast.makeText(requireContext(),
                            "User already exists",
                            Toast.LENGTH_SHORT).show();
            }
            //if all is well, display message to user that creation is successful
            else {
                // creates a secure hash using the password value
                String securePassword = PasswordSecurity.hashPassword(password);

                // adds the user to the database
                userDAO.addUser(new UserTable(username, securePassword));
                Toast.makeText(requireContext(),
                        "user created", Toast.LENGTH_SHORT).show();
            }
        });

        return rootView;
    }
}
