package com.zybooks.cs360projecttwoedwarddethridge;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class TextPermissions extends Fragment {
    private static final int SMS_PERMISSION_CODE = 100;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.fragment_text_permissions, container, false);

        // instantiates our buttons
        Button denyButton = rootView.findViewById(R.id.denyButton);
        Button confirmButton = rootView.findViewById(R.id.confirmButton);

        // adds click listener to the confirm button
        confirmButton.setOnClickListener(v->{
            // if user clicks the button and sms permissions have not been accepted
            if (ContextCompat.checkSelfPermission(requireContext(),
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                // prompt system to ask user tor sms permission
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 100);

            } else {
                //inform user that permissions had already been accepted
                Toast.makeText(requireContext(),
                        "Permission already accepted",
                        Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(TextPermissions.this)
                        .navigate(R.id.action_sms_to_grid);
            }
        });

        // click listener when deny button clicked move to database grid
        denyButton.setOnClickListener(v -> {
            NavHostFragment.findNavController(TextPermissions.this)
                    .navigate(R.id.action_sms_to_grid);
        });
        return rootView;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // once option has been chosen
        if (requestCode == SMS_PERMISSION_CODE) {
            // if user accepts enable sms
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // navigate back to grid
                NavHostFragment.findNavController(TextPermissions.this)
                        .navigate(R.id.action_sms_to_grid);
            } else {
                // User denied permission and navigate back to grid
                NavHostFragment.findNavController(TextPermissions.this)
                        .navigate(R.id.action_sms_to_grid);
            }
        }
    }
}