package com.zybooks.cs360projecttwoedwarddethridge;

import android.app.DatePickerDialog;
import android.content.Context;
import android.widget.TextView;
import java.util.Calendar;

// this class implements a calendar so the user can select the date they filled their medication and
// how many days it should last them so that the refill date can be calculated
public class DateManager {

    // this stores the date as a number so we can add to it easily later
    public static long createDate(int year, int month, int day) {

        Calendar calendar = Calendar.getInstance();

        calendar.set(
                year,
                month,
                day,
                0,
                0,
                0
        );

        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTimeInMillis();
    }

    // this displays the calendar so the user can pick the date they filled their medication
    public static void showDatePicker(
            Context context,
            DateSelectedListener listener) {

        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                context,
                (view, selectedYear, selectedMonth, selectedDay) -> {

                    long selectedDate = createDate(
                            selectedYear,
                            selectedMonth,
                            selectedDay
                    );

                    // this stores the date selected for use later
                    listener.onDateSelected(selectedDate);
                },
                year,
                month,
                day
        );

        datePickerDialog.show();
    }

    // this allows us to add the days of supply to our date selected
    public static long addDays(long date, int days) {

        Calendar calendar = Calendar.getInstance();
        // sets the calendar to the current selected date
        calendar.setTimeInMillis(date);
        // adds the number of days selected to the original date
        calendar.add(Calendar.DAY_OF_MONTH, days);

        // returns the new calculated date
        return calendar.getTimeInMillis();
    }

    // converts the long back into a readable date
    public static String formatDate(long date) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(date);

        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int year = calendar.get(Calendar.YEAR);

        // returns a string of the converted long
        return month + "/" + day + "/" + year;
    }
    public interface DateSelectedListener {
        void onDateSelected(long date);
    }
}