package com.zybooks.cs360projecttwoedwarddethridge;

import android.content.Context;
import android.content.SharedPreferences;

// this class manages each user session individually
public class SessionManager {

    private final SharedPreferences preferences;

    public SessionManager(Context context) {
        preferences = context.getSharedPreferences(
                "user_session",
                Context.MODE_PRIVATE
        );
    }

    // this saves our username for use in persistent storage
    public void login(String username) {
        preferences.edit()
                .putString("username", username)
                .apply();
    }

    // this gets the username saved in the previous function
    public String getUsername() {
        return preferences.getString("username", null);
    }

    // this handles removing the username swe saved when a user logs out
    public void logout() {
        preferences.edit()
                .remove("username")
                .apply();
    }
}