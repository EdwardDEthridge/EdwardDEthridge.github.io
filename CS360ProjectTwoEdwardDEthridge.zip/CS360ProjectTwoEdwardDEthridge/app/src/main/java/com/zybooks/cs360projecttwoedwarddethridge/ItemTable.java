package com.zybooks.cs360projecttwoedwarddethridge;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

// class controls how items are represented in the database
@Entity(tableName = "items")
public class ItemTable {

    @PrimaryKey(autoGenerate = true)
    public long id;

    public String name;
    public int quantity;
    public String username;
    public long date;

    public ItemTable(String name, int quantity, String username, long date) {
        this.name = name;
        this.quantity = quantity;
        this.username = username;
        this.date = date;
    }
}