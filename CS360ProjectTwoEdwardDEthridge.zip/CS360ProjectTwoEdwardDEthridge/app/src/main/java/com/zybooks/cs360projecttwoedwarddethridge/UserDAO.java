package com.zybooks.cs360projecttwoedwarddethridge;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface UserDAO {

    // add user
    @Insert
    long addUser(UserTable user);

    // Check credentials
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    UserTable getUser(String username);

    // Confirm user exists in database
    @Query("SELECT COUNT(*) > 0 FROM users WHERE username = :username")
    boolean userExists(String username);

}