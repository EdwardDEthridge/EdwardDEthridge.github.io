package com.zybooks.cs360projecttwoedwarddethridge;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ItemDAO {

    // CREATE
    @Insert
    long addItem(ItemTable item);

    // READ
    @Query("SELECT * FROM items WHERE username = :username")
    List<ItemTable> getAllItems(String username);

    @Query("SELECT * FROM items WHERE id = :id")
    ItemTable getItemById(long id);

    @Query("SELECT EXISTS(SELECT 1 FROM items WHERE name = :name LIMIT 1)")
    boolean itemExists(String name);

    @Query("SELECT * FROM items WHERE name = :name LIMIT 1")
    ItemTable getItemByName(String name);

    // UPDATE
    @Update
    void updateItem(ItemTable item);

    // DELETE (single)
    @Query("DELETE FROM items WHERE id = :id")
    void removeItem(long id);

}