package com.zybooks.cs360projecttwoedwarddethridge;

import android.content.Context;

import androidx.room.Room;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {ItemTable.class, UserTable.class}, version = 4)
public abstract class ProjectDatabase extends RoomDatabase {

    public abstract ItemDAO itemDAO();
    public abstract UserDAO userDAO();
}