package com.zybooks.cs360projecttwoedwarddethridge;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private ItemDAO itemDAO;

    //when recycler view is created
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_grid, parent, false);

        return new ViewHolder(view);
    }
    //a list of all items in our database
    private List<ItemTable> itemList;

    //adapter for the recycler view
    public ItemAdapter(ItemDAO itemDAO, List<ItemTable> itemList) {
        this.itemDAO = itemDAO;
        this.itemList = itemList;
    }

    //required but not used
    @Override
    public int getItemCount() {
        return itemList == null ? 0 : itemList.size();
    }

    //view holder for all of our buttons and item attributes
    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView name, quantity, date;
        Button remove, update;

        // this adds functionality for all of our buttons for later user
        public ViewHolder(View view) {
            super(view);

            // store our grid elements for use later
            name = view.findViewById(R.id.itemName);
            quantity = view.findViewById(R.id.itemQuantity);
            date = view.findViewById(R.id.itemDate);
            remove = view.findViewById(R.id.removeButton);
            update = view.findViewById(R.id.updateButton);
        }
    }

    //this controls the logic of our buttons
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ItemTable item = itemList.get(position);

        //holds the values for our item that we've selected by pushing our button
        holder.name.setText(item.name);
        holder.quantity.setText(String.valueOf(item.quantity));
        holder.date.setText(DateManager.formatDate(item.date));

        // adds functionality to remove button
        holder.remove.setOnClickListener(v -> {
            int pos = holder.getBindingAdapterPosition();
            //if an item exists at the position we select
            if (pos != RecyclerView.NO_POSITION) {
                //remove the item from the grid
                itemList.remove(pos);
                //remove the item from the database
                itemDAO.removeItem(item.id);
                //notify us of which item was removed
                notifyItemRemoved(pos);
            }
        });

        // runs the navigation to the update screen when update is clicked
        holder.update.setOnClickListener(v -> {
            int pos = holder.getBindingAdapterPosition();
            //check that item exists
            if(pos != RecyclerView.NO_POSITION){
                ItemTable selectedItem = itemList.get(pos);

                Bundle bundle = new Bundle();
                bundle.putLong("itemId", selectedItem.id);

                // navigate to update screen
                Navigation.findNavController(v)
                        .navigate(R.id.action_grid_to_update, bundle);
            }
        });
    }
    //resets the data table to present the new values
    public void setItems(List<ItemTable> items) {
        this.itemList = items;
        notifyDataSetChanged();
    }
}

