package com.zybooks.cs360projecttwoedwarddethridge;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class UserTable {

    @PrimaryKey(autoGenerate = true)
    public long id;

    public String username;
    public String password;

    public UserTable(String username, String password) {
        this.username = username;
        this.password = password;
    }
}